<div class="wrapper col5">
  <div id="footer">

    <div id="copyright">
      <p class="fl_left">DMCP DISSANAYAKE-SEU/IS/16/PS041
           <a href="adminlogin.php"><mark>
		   Admin Login Panel</mark>
		   </a>|||||||||||||||||

		   <a href="doctorlogin.php"><mark>
		   Doctor Login Panel</mark>
		   </a></p>
      <p class="fl_right">Developed by chalitha pramod </p>
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>