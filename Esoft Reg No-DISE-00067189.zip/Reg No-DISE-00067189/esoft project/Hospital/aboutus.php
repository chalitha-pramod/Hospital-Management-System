<?php
include("header.php");
?>
<div class="wrapper col2">
  <div id="gallery">
    <ul>
      <li class="placeholder" style="background-image:url(images/demo/image1.jpg);">Image Holder</li>
      <li><a class="swap" style="background-image:url(images/demo/img3.jpg);" href="#gallery"><strong>Services</strong><span><img src="images/demo/image1.jpg" alt="" /></span></a></li>
      <li><a class="swap" style="background-image:url(images/demo/img1.jpg);" href="#gallery"><strong>Products</strong><span><img src="images/demo/shr_290913_hospital2.jpg" alt="" /></span></a></li>
      <li class="last"><a class="swap" style="background-image:url(images/demo/img2.jpg);" href="#gallery"><strong>Company</strong><span><img src="images/demo/shr_290913_hospital5.jpg" alt="" /></span></a></li>
    </ul>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
    <div id="content">
      <h1>About Ceylon Hospital</h1>
      <p align="justify">A hospital is a health care institution providing patient treatment with specialized medical and nursing
	  staff and medical equipment. The best-known type of hospital is the general hospital, which typically has an 
	  emergency department to treat urgent health problems ranging from fire and accident victims to a sudden illness.
	  A district hospital typically is the major health care facility in its region, with many beds for intensive 
	  care and additional beds for patients who need long-term care. Specialized hospitals include trauma centers,
	  rehabilitation hospitals, children's hospitals, seniors' hospitals, and hospitals for dealing with specific medical
	  needs such as psychiatric treatment and certain disease categories. Specialized hospitals can help reduce health care 
	  costs compared to general hospitals. Hospitals are classified as general,
	  specialty, or government depending on the sources of income received.</p>
      <div class="homecontent">
        <ul>
          <li>
           <h2>Super Specialty Hospital</h2>
            <p class="imgholder"><img src="images/spciality.jpg" alt="" style="width:286px;height:100px;"  /></p>
          </li>
          <li class="last">
            <h2>24X7 services</h2>
            <p class="imgholder"><img src="images/24x7.png" alt="" style="width:286px;height:100px;"   /></p>
          </li>
        </ul>
        <div class="clear"></div>
      </div>
      <p><strong>Directors message:</strong><br />
      Keeping in with the prime objective of the Ceylon Society of providing value based education and social service, the SDM College of Medical Sciences &amp; Hospital, Dharwad was established in the year 2003 to address the ever growing demand by the society for quality health care professionals delivering quality health care through quality infrastructure at an affordable cost to alleviate human suffering through healing hands.</p>
    </div>
    <div id="column">
      <div id="featured">
        <ul>
          <li>
            <h2>Our Services</h2>
            <p class="imgholder"><img src="images/SDM-Image-5.png" alt="" style="width:240px;height:90px;" /></p>
          </li>
          <li role="menuitem">Ceylon Hospital</li>
          <li aria-haspopup="Sidebar1_Menu2:submenu:36" role="menuitem">Diagnostic Services</li>
          <li role="menuitem">Consultation</li>
          <li role="menuitem">In Patient Services</li>
          <li role="menuitem">Health Checkup Packages</li>
          <li role="menuitem">24 X 7 Services</li>
          <li role="menuitem">Physiotherapy Services</li>
          <li role="menuitem"><a href=""  tabindex="-1">Dialysis</a></li>
          <li role="menuitem"><a href=""  tabindex="-1">Insurance Schemes</a></li>
        </ul>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</div>
<?php
include("footer.php");
?>