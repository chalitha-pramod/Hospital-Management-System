<?php
include("header.php");
?>
<div class="wrapper col1">
  <div id="container">
    <div id="content">
      <h1 style="color:red"><b>Welcome to Ceylon Hospital</b></h1>
      <p style="color:green">Our History-
Lanka Hospitals Corporation PLC commenced operations in Sri Lanka on 7th June 2002, under the brand name of Apollo Hospitals,
 a part of the chain of Apollo Hospitals founded by the renown Dr. Pratap C. Reddy in India. As the only purpose built private
 hospital of its kind in Sri Lanka. Apollo Colombo revolutionised Sri Lankas healthcare service,and today under the brand 
 Lanka Hospitals.we continue to dominate and lead the healthcare sector. Ours is still considered to be the best health care
 facility in the country.

In 2012,we celebrated a decade of excellence in healthcare. Over the past decade, Lanka Hospitals has revolutionized the 
healthcare industry in Sri Lanka through infrastructure development and advancement of its product and services,through 
sizeable investments.ith a view to deliver healthcare that is on par with global developments in medical technology. 
We also play a critical role in the nations strategy to provide to provide world-class medical care whilst balancing the 
equation of affordability and accessibility for all Sri Lankans.</p>
      <p>Our Promise-
We believe that every person has the right to be treated with utmost respect and consideration Therefore at Lanka Hospitals
 we care about our patients We care about their families who are anxious and concerned. We care about our colleagues and how
 we as a team provide the best care to our patients.
Because we care.we will be sincere,compassionate and sensitive to make a difference in the lives we touch</p>
      <p>	</p>
      <p></p>

      <div class="homecontent">
        <ul>
          <li>
            <h2>Booking Appointment online   </h2>
            <p><a href="patientappointment.php"><mark>Appointment</mark></a></p>
          </li>
          <li class="last">
            <h2>Login for users</h2>          
            <p><a href="patientlogin.php"><mark>Login</mark></a></p>
          </li>
        </ul>
        <div class="clear"></div>
      </div>
    </div>
   
    <div class="clear"></div>
  </div>
</div>
<?php
include("footer.php");
?>